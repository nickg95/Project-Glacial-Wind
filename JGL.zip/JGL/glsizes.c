#include "glcorearb.h"
#include <stdio.h>

int main(int argc, char* argv[])
{
	printf("GLintptr: %d\n",sizeof(GLintptr));
	return 0;
}
