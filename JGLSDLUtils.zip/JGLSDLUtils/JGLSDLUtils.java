package JGLSDLUtils;	
import java.io.*;
import java.nio.*;
import java.nio.file.*;

public class JGLSDLUtils {
	private static int ostype=0;
	private static int osbits=0;
	private static File tmpdir;
	//http://stackoverflow.com/questions/228477/how-do-i-programmatically-determine-operating-system-in-java
	public static void extractAndLoad(Class c, String dll){
        try{
            //System.out.println("Extract and load:"+c+" "+dll);
            if( ostype == 0 ){
                String o = System.getProperty("os.name");
                o = o.toLowerCase();
                if( o.indexOf("win") != -1 )
                    ostype = 1;
                else if( o.indexOf("linux") != -1 )
                    ostype = 2;
                else
                    ostype = 3;
                String tmp = System.getProperty("os.arch");    //x86 or amd64
                if( tmp.equals("x86"))
                    osbits=32;
                else
                    osbits=64;    //amd64 or x64 or whatever...
                
                Path tmppath = Files.createTempDirectory(null);
                tmpdir = tmppath.toFile();
                
                tmpdir.deleteOnExit();
                String ptmp = System.getProperty("java.library.path");
                if( ptmp == null )
                    ptmp = tmpdir.toString();
                else
                    ptmp = ptmp+File.pathSeparator+tmpdir.toString();
                System.setProperty("java.library.path",ptmp);
                //System.out.println("jlp="+ptmp);
            }
		    String infile;
		    String outfile;
		    
			if( ostype == 1 ){
				infile = "/libs/windows"+osbits+"/"+dll+".dll";
				outfile=dll+".dll";
			}
			else if( ostype == 2 ){
				infile = "/libs/linux"+osbits+"/"+dll+".so";
				outfile=dll+".so";
			}
			else{
			    throw new RuntimeException("Unknown platform");
			}
			
			InputStream in = c.getResourceAsStream(infile);
			
			if( in == null ){
				System.err.println("Cannot find library resource "+infile);
				System.exit(1);
			}
			
			File outf = new File(tmpdir+File.separator+outfile);
			
			/*
			if( ostype == 1 ){
				outf = java.io.File.createTempFile(dll,"dll",null);
				dll += ".dll";
			}
			else if(ostype == 2){
				outf = java.io.File.createTempFile(dll,"so",null);
				dll += ".so";
			}
			else{
				System.out.println("Don't know about this OS");
				System.exit(1);
				return;
			}
			*/
			
			outf.deleteOnExit();
			FileOutputStream out = new FileOutputStream(outf);
			byte[] b = new byte[1024];
			while(true){
				int num = in.read(b);
				if( num == -1 )
					break;
				out.write(b,0,num);
			}
			in.close();
			out.close();
			//System.out.println("About to load "+outf.getPath());
			System.load(outf.getPath());
			//System.out.println("loaded");
		}
		catch(IOException e){
			throw new RuntimeException("Could not extract library "+dll+": "+e);
		}
	}    
}
