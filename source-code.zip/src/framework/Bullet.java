package framework;

import framework.math3d.mat4;
import static framework.math3d.math3d.*;
import framework.math3d.vec2;
import framework.math3d.vec4;
import java.util.ArrayList;

public class Bullet 
{
    vec4 pos, worldPos, axis;
    float vel, lifeLeft, state, alpha;
    int type;
    boolean fromPlayer, removed;
    Mesh mesh, exMesh;
    mat4 translate;
    Circle circle;
    
    public Bullet(vec4 bpos, vec4 a, float bvel, float blifetime, boolean player, int t, Mesh bmesh)
    {
        pos = bpos;
        axis = a;
        vel = bvel;
        lifeLeft = blifetime;
        fromPlayer = player;
        removed = false;
        state = 0;
        type = t;
        alpha = (float) 1.0;
        mesh = bmesh;
        exMesh = null;
        translate = translation(pos);
        worldPos = new vec4(0, 0, 0, 1);
        worldPos = mul(worldPos, translate);
        circle = new Circle(worldPos, (float) 0.3, axis);
    }
    
    public void draw(Program prog)
    {
        if(lifeLeft <= 0)
            return;
        translate = translation(pos);
        worldPos = new vec4(0, 0, 0, 1);
        worldPos = mul(worldPos, translate);
        prog.setUniform("worldMatrix", translate);
        prog.setUniform("bpScale", new vec2(.3, .3));
        prog.setUniform("state", state);
        prog.setUniform("alpha", alpha);
        mesh.draw(prog);
    }
    
    public void update(float elapsed, ArrayList<Explosion> explosions, Program prog, Player player)
    {
        if(!removed)
            pos = add(pos, mul(elapsed*vel, axis));
        lifeLeft -= elapsed;
        circle.center = worldPos;
        if(lifeLeft <= 1.7)
            state = 1;
        if(state == 1)
            alpha -= elapsed;
        if(type == 1)
        {
            axis.y -= .2f*elapsed;
            if(!removed && pos.y < -0.5f)
            {
                alpha = 0.0f;
                Explosion e = new Explosion(pos, exMesh);
                e.scale = new vec2(2, 2);
                explosions.add(e);
                removed = true;
            }
            if(!removed && this.hit(player.circle))
            {
                alpha = 0.0f;
                Explosion e = new Explosion(pos, exMesh);
                e.scale = new vec2(2, 2);
                explosions.add(e);
                removed = true;
            }
        }
    }
    
    public boolean hit(Circle other)
    {
        vec4 V = sub(circle.center, other.center);
        float D = length(V);
        return D <= circle.radius + other.radius;
    }
}
