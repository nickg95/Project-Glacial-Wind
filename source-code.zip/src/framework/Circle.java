package framework;

import static framework.math3d.math3d.add;
import static framework.math3d.math3d.length;
import static framework.math3d.math3d.mul;
import static framework.math3d.math3d.sub;
import framework.math3d.vec4;

public class Circle 
{
    vec4 center, axis;
    float radius;
    
    public Circle(vec4 c, float r, vec4 a)
    {
        center = c;
        radius = r;
        axis = a;
    }
    
    public void update(float elapsed)
    {
        center = add(center, mul(axis, elapsed));
    }
    
    public boolean hit(Circle other)
    {
        vec4 V = sub(this.center, other.center);
        float dist = length(V);
        return dist <= this.radius + other.radius;
    }
}
