package framework;

import static framework.math3d.math3d.*;
import framework.math3d.mat4;
import framework.math3d.vec3;
import framework.math3d.vec4;

public class Enemy 
{
    vec4 pos, worldPos, U, V, W;
    float turnDegrees, bulletTimer, turn_timer, steering, wheelSpin, state, alpha;
    int is_turning, direction, type, health;
    Mesh mesh, wheelMesh;
    mat4 scale, rotate, turnRotate, translate, worldMatrix;
    Circle circle;
    
    public Enemy(vec4 p, Mesh m, Mesh w, int t)
    {
        pos = p;
        type = t;
        turnDegrees = 0;
        bulletTimer = 0;
        is_turning = 0;
        turn_timer = 0;
        direction = 0;
        steering = 0;
        wheelSpin = 0;
        state = 0;
        health = 1;
        alpha = (float) 1.0;
        mesh = m;
        wheelMesh = w;
        U = new vec4(1, 0, 0, 0);
        V = new vec4(0, 1, 0, 0);
        W = new vec4(0, 0, 1, 0);
        scale = scaling(new vec3(0.22, 0.22, 0.22));
        rotate = new mat4(U.x, U.y, U.z, 0,
                               V.x, V.y, V.z, 0,
                               W.x, W.y, W.z, 0,
                               0, 0, 0, 1);
        turnRotate = axisRotation(new vec3(0, 1, 0), turnDegrees);
        translate = translation(pos);
        worldMatrix = mul(scale, rotate, turnRotate, translate);
        worldPos = new vec4(0, 0, 0, 1);
        worldPos = mul(worldPos, worldMatrix);
        circle = new Circle(worldPos, (float) 0.3, W);
    }
    
    public Enemy(vec4 p, Mesh m, int t)
    {
        pos = p;
        bulletTimer = 0;
        state = 0;
        alpha = 1.0f;
        type = t;
        mesh = m;
        health = 3;
        U = new vec4(1, 0, 0, 0);
        V = new vec4(0, 1, 0, 0);
        W = new vec4(0, 0, 1, 0);
        scale = scaling(new vec3(.5, .5, .5));
        rotate = new mat4(U.x, U.y, U.z, 0,
                          V.x, V.y, V.z, 0,
                          W.x, W.y, W.z, 0,
                          0, 0, 0, 1);
        translate = translation(pos);
        worldMatrix = mul(scale, rotate, translate);
        worldPos = new vec4(0, 0, 0, 1);
        worldPos = mul(worldPos, worldMatrix);
        circle = new Circle(pos, 0.3f, W);
    }
    
    public void draw(Program prog)
    {
        if(type == 0)
        {
            rotate = new mat4(U.x, U.y, U.z, 0,
                                   V.x, V.y, V.z, 0,
                                   W.x, W.y, W.z, 0,
                                   0, 0, 0, 1);
            turnRotate = axisRotation(new vec3(0, 1, 0), turnDegrees);
            translate = translation(new vec4(pos));
            worldMatrix = mul(scale, rotate, turnRotate, translate);
            worldPos = new vec4(0, 0, 0, 1);
            worldPos = mul(worldPos, worldMatrix);
            prog.setUniform("worldMatrix", worldMatrix);
            prog.setUniform("alpha", alpha);
            mesh.draw(prog);
            vec4 flwPos = new vec4(0.8, 0.4, 1.15, 1);
            vec4 frwPos = new vec4(-0.8, 0.4, 1.15, 1);
            vec4 blwPos = new vec4(0.8, 0.4, -1.6, 1);
            vec4 brwPos = new vec4(-0.8, 0.4, -1.6, 1);
            mat4 frontLeftWheelTranslate = translation(new vec3(flwPos.xyz()));
            mat4 frontRightWheelTranslate = translation(new vec3(frwPos.xyz()));
            mat4 backLeftWheelTranslate = translation(new vec3(blwPos.xyz()));
            mat4 backRightWheelTranslate = translation(new vec3(brwPos.xyz()));
            mat4 wheelRotation = axisRotation(new vec3(1, 0, 0), wheelSpin);
            mat4 wheelTurn = axisRotation(new vec3(0, 1, 0), steering);
            mat4 M = mul(wheelRotation, wheelTurn, frontLeftWheelTranslate, turnRotate, rotate, scale, translate);
            prog.setUniform("worldMatrix", M);
            wheelMesh.draw(prog);
            M = mul(wheelRotation, wheelTurn, frontRightWheelTranslate, turnRotate, rotate, scale, translate);
            prog.setUniform("worldMatrix", M);
            wheelMesh.draw(prog);
            M = mul(wheelRotation, wheelTurn, backLeftWheelTranslate, turnRotate, rotate, scale, translate);
            prog.setUniform("worldMatrix", M);
            wheelMesh.draw(prog);
            M = mul(wheelRotation, wheelTurn, backRightWheelTranslate, turnRotate, rotate, scale, translate);
            prog.setUniform("worldMatrix", M);
            wheelMesh.draw(prog);
        }
        else if(type == 1)
        {
            rotate = new mat4(U.x, U.y, U.z, 0,
                                   V.x, V.y, V.z, 0,
                                   W.x, W.y, W.z, 0,
                                   0, 0, 0, 1);
            translate = translation(new vec4(pos));
            worldMatrix = mul(scale, rotate, translate);
            worldPos = new vec4(0, 0, 0, 1);
            worldPos = mul(worldPos, worldMatrix);
            prog.setUniform("worldMatrix", worldMatrix);
            prog.setUniform("alpha", alpha);
            mesh.draw(prog);
        }
    }
    
    public void update(float elapsed)
    {
        if(state == 1)
            alpha -= elapsed;
        circle.center = worldPos;
        circle.axis = W;
    }
    
    public void drive(float a)
    {
        if(type == 0)
        {
            pos = add(pos, mul(a, W));
        }
        else if(type == 1)
        {
            pos = add(pos, mul(a, U));
        }
    }
    
    public void turn(float a)
    {
        mat4 M = axisRotation(V, a);
        U = mul(U, M);
        W = mul(W, M);
    }
}
