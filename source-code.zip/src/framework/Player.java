package framework;

import framework.math3d.mat4;
import static framework.math3d.math3d.add;
import static framework.math3d.math3d.axisRotation;
import static framework.math3d.math3d.mul;
import static framework.math3d.math3d.scaling;
import static framework.math3d.math3d.translation;
import framework.math3d.vec3;
import framework.math3d.vec4;

public class Player 
{
    float turnDegrees, bulletTimer, axisChange, steering, wheelSpin, state, alpha;
    float acceleration, velocity, maxVel;
    Mesh mesh, wheelMesh;
    vec4 pos, worldPos, U, V, W;
    mat4 scale, rotate, translate, turnRotate, wheelRotation, wheelTurn, carWorld, flwWorld, frwWorld, blwWorld, brwWorld;
    Circle circle;
    boolean gotHit;
    
    public Player(vec4 p, Mesh m, Mesh w)
    {
        pos = p;
        turnDegrees = 0;
        bulletTimer = 0;
        axisChange = 0;
        steering = 0;
        wheelSpin = 0;
        state = 0;
        alpha = (float) 1.0;
        acceleration = .2f;
        velocity = 0;
        maxVel = 3;
        mesh = m;
        wheelMesh = w;
        U = new vec4(1, 0, 0, 0);
        V = new vec4(0, 1, 0, 0);
        W = new vec4(0, 0, 1, 0);
        scale = scaling(new vec3(0.22, 0.22, 0.22));
        rotate = new mat4(U.x, U.y, U.z, 0,
                               V.x, V.y, V.z, 0,
                               W.x, W.y, W.z, 0,
                               0, 0, 0, 1);
        turnRotate = axisRotation(new vec3(0, 1, 0), turnDegrees);
        translate = translation(pos);
        wheelRotation = mat4.identity();
        wheelTurn = mat4.identity();
        carWorld = mul(scale, rotate, turnRotate, translate);
        worldPos = new vec4(0, 0, 0, 1);
        worldPos = mul(worldPos, carWorld);
        circle = new Circle(worldPos, (float) 0.3, W);
        gotHit = false;
    }
    
    public void draw(Program prog)
    {
        turnRotate = axisRotation(new vec3(0, 1, 0), turnDegrees);
        translate = translation(pos);
        carWorld = mul(scale, rotate, turnRotate, translate);
        worldPos = new vec4(0, 0, 0, 1);
        worldPos = mul(worldPos, carWorld);
        prog.setUniform("worldMatrix", carWorld);
        prog.setUniform("alpha", alpha);
        mesh.draw(prog);
        vec4 flwPos = new vec4(0.8, 0.4, 1.15, 1);
        vec4 frwPos = new vec4(-0.8, 0.4, 1.15, 1);
        vec4 blwPos = new vec4(0.8, 0.4, -1.6, 1);
        vec4 brwPos = new vec4(-0.8, 0.4, -1.6, 1);
        mat4 frontLeftWheelTranslate = translation(new vec3(flwPos.xyz()));
        mat4 frontRightWheelTranslate = translation(new vec3(frwPos.xyz()));
        mat4 backLeftWheelTranslate = translation(new vec3(blwPos.xyz()));
        mat4 backRightWheelTranslate = translation(new vec3(brwPos.xyz()));
        wheelRotation = axisRotation(new vec3(1, 0, 0), wheelSpin);
        wheelTurn = axisRotation(new vec3(0, 1, 0), steering);
        flwWorld = mul(wheelRotation, wheelTurn, frontLeftWheelTranslate, turnRotate, rotate, scale, translate);
        prog.setUniform("worldMatrix", flwWorld);
        wheelMesh.draw(prog);
        frwWorld = mul(wheelRotation, wheelTurn, frontRightWheelTranslate, turnRotate, rotate, scale, translate);
        prog.setUniform("worldMatrix", frwWorld);
        wheelMesh.draw(prog);
        blwWorld = mul(wheelRotation, backLeftWheelTranslate, turnRotate, rotate, scale, translate);
        prog.setUniform("worldMatrix", blwWorld);
        wheelMesh.draw(prog);
        brwWorld = mul(wheelRotation, backRightWheelTranslate, turnRotate, rotate, scale, translate);
        prog.setUniform("worldMatrix", brwWorld);
        wheelMesh.draw(prog);
    }
    
    public void update(float elapsed)
    {
        circle.center = worldPos;
        circle.axis = W;
        if(gotHit)
        {
            if(state == 1)
            {
                alpha = 0;
            }
            else
                alpha = 1.0f;
        }
        else
            alpha = 1.0f;
    }
    
    public void compute_axis_matrix(float elapsed)
    {
        mat4 T = axisRotation(V, axisChange * elapsed);
        W = mul(W, T);
        U = mul(U, T);
        rotate = new mat4(U.x, U.y, U.z, 0,
                               V.x, V.y, V.z, 0,
                               W.x, W.y, W.z, 0,
                               0, 0, 0, 1);
    }
    
    public void drive(float a, int dir)
    {
        if(dir == 0 && velocity< maxVel)
        {
            velocity += acceleration;
        }
        else if(dir == 1 && velocity > -3)
        {
            velocity -= acceleration;
        }
        pos = add(pos, mul(velocity*a, W));
    }
    
    public void slow(float a, int dir)
    {
        if(dir == 0 && velocity > 0)
        {
            if(velocity < 0)
                velocity = 0;
            velocity -= acceleration;
            pos = add(pos, mul(velocity*a, W));
        }
        else if(dir == 1 && velocity < 0)
        {
            velocity += acceleration;
            pos = add(pos, mul(velocity*a, W));
        }
    }
    
    public void turn(float a)
    {
        mat4 M = axisRotation(V, a);
        U = mul(U, M);
        W = mul(W, M);
    }
}
