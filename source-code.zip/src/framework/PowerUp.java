package framework;

import static framework.math3d.math3d.*;
import framework.math3d.mat4;
import framework.math3d.vec2;
import framework.math3d.vec3;
import framework.math3d.vec4;

public class PowerUp 
{
    static final int BOOST = 0;
    static final int HEALTH = 1;
    static final int SPEED = 2;
    static final int RAPIDFIRE = 3;
    static final int SHIELD = 4;
    
    int type;
    vec4 pos;
    Mesh mesh;
    mat4 scale;
    mat4 translate;
    
    public PowerUp(vec4 p, int t, Mesh m)
    {
        pos = p;
        type = t;
        mesh = m;
        scale = scaling(new vec3(10, 10, 10));
        translate = translation(pos);
    }
    
    public void draw(Program prog)
    {
        prog.setUniform("worldMatrix", translate);
        prog.setUniform("bpScale", new vec2(.5, .5));
        prog.setUniform("mode", 4);
        mesh.draw(prog);
    }
}
