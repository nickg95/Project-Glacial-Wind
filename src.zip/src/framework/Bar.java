package framework;

import framework.math3d.mat4;
import framework.math3d.vec3;
import framework.math3d.vec4;
import static framework.math3d.math3d.*;

public class Bar 
{
    vec4 pos;
    Mesh background;
    Mesh bar;
    mat4 bgscale, bgtranslate, barscale, bartranslate;
    float barlength;
    
    public Bar(vec4 p, Mesh bg, Mesh br)
    {
        pos = p;
        background = bg;
        bar = br;
        barlength = (float) .3;
        bgscale = scaling(new vec3(.2, .2, .2));
        bgtranslate = translation(pos);
        barscale = scaling(new vec3(barlength, .05, .1));
        bartranslate = translation(new vec3(pos.x+(barlength+.15), pos.y+.02, .1));
    }
    
    public void draw(Program prog)
    {
        barscale = scaling(new vec3(barlength, .05, .1));
        bartranslate = translation(new vec3(pos.x+(barlength+.15), pos.y+.02, .1));
        prog.setUniform("worldMatrix", mul(bgscale, bgtranslate));
        prog.setUniform("viewMatrix", mat4.identity());
        prog.setUniform("projMatrix", mat4.identity());
        background.draw(prog);
        prog.setUniform("worldMatrix", mul(barscale, bartranslate));
        bar.draw(prog);
    }
}
