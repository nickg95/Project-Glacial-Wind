package framework;

import framework.math3d.mat4;
import framework.math3d.vec3;
import framework.math3d.vec4;
import static framework.math3d.math3d.*;
import static JGL.JGL.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class Functions 
{
    public static Random R = new Random();
    
    public static mat4 calculateFlattenMatrix(Camera cam)
    {
        float A, B, C, x, y, z, D;
        mat4 T, M, T1, F, viewMatrix, shadowMatrix, nitroTranslate;
        vec4 groundNormal, groundPoint;
        
        groundNormal = new vec4(0, 1, 0, 0);
        A = groundNormal.x;
        B = groundNormal.y;
        C = groundNormal.z;
        groundPoint = new vec4(0, 0, 0, 1);
        x = groundPoint.x - 50;
        y = groundPoint.y - 50;
        z = groundPoint.z - 50;
        D = -((A*x)+(B*y)+(C*z));
        T = translation(new vec3(-50, -50, -50));
        T1 = translation(new vec3(50, 50, 50));
        M = new mat4(-D, 0, 0, A, 0, -D, 0, B, 0, 0, -D, C, 0, 0, 0, 0);
        F = mul(T, M);
        F = mul(F, T1);
        viewMatrix = cam.viewMatrix;
        shadowMatrix = mul(F, viewMatrix).negate();
        return shadowMatrix;
    }
    
    public static void spawnPowerups(Mesh boost, Mesh health, Mesh speed, Mesh rf, Mesh shield, ArrayList<PowerUp> powerups)
    {
        Random rand = new Random();
        for(int i = 0; i < 100; i++)
        {
            for(int j = 0; j < 100; j++)
            {
                if(i % 10 == 0 && j % 10 == 0)
                {
                    Mesh mesh;
                    int r = rand.nextInt(2);
                    int t = rand.nextInt(5);
                    if(r == 0)
                    {
                        switch(t)
                        {
                            case(0):
                                mesh = boost;
                                break;
                            case(1):
                                mesh = health;
                                break;
                            case(2):
                                mesh = speed;
                                break;
                            case(3):
                                mesh = rf;
                                break;
                            default:
                                mesh = shield;
                                break;
                        }
                        PowerUp p = new PowerUp(new vec4(i, 0, j, 1), t, mesh);
                        powerups.add(p);
                    }
                }
            }
        }
    }
    
    public static vec4 fixCamEyeToPlayer(Camera cam, Player player)
    {
        vec4 newV = new vec4(sub(player.pos, cam.eye));
        cam.eye.y = (float) (player.pos.y + 0.6);
        cam.eye.z = sub(player.pos, player.W).z;
        cam.eye.x = sub(player.pos, player.W).x;
        return newV;
    }
    
    public static void draw_sky(Program skyprog, Camera cam, vec4 eyePosCopy, Mesh skybox)
    {
        skyprog.use();
        cam.draw(skyprog);
        skyprog.setUniform("worldMatrix", translation(eyePosCopy)); // Used eyePosCopy instead of cam.eye to avoid jittering (doesn't account for slight camera changes when driving)
        skybox.draw(skyprog);
    }
    
    public static int draw_scene_normally(Program prog, Camera cam, Player player,
                                           float elapsed, boolean boosting, boolean shielded,
                                           int nitroFrame, float carAngle, Mesh nitro, Mesh shield, Mesh ground)
    {
        prog.use();
        //glStencilFunc(GL_ALWAYS, 1, ~0);
        //glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
        prog.use();
        prog.setUniform("lightPos",new vec3(50,50,50) );

        vec3 eye3 = new vec3(cam.eye.x, cam.eye.y, cam.eye.z);
        vec3 carPos3 = new vec3(player.pos.x, player.pos.y, player.pos.z);
        vec3 up = new vec3(0, 1, 0);
        cam.lookAt(eye3, carPos3, up);
        
        prog.setUniform("mode", 1);
        prog.setUniform("worldMatrix", translation(new vec3(0, -.15, 0)));
        //glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
        ground.draw(prog);
        cam.draw(prog);
        prog.setUniform("mode", 0);

        prog.setUniform("mode", 0);
        player.draw(prog);
        player.update(elapsed);
        if(boosting)
        {
            if(nitroFrame == 15)
                nitroFrame = 0;
            else
                nitroFrame++;
            int col = (nitroFrame % 4);
            int row = 3 - (nitroFrame / 4);
            mat4 textureMatrix = mul(scaling(new vec3(.25, .25, 1)), translation(col*.25f, row*.25f, 0));
            prog.setUniform("textureMatrix", textureMatrix);
            vec3 nitroPos = new vec3(sub(player.pos, player.W).x, sub(player.pos, player.W).y+.3f, sub(player.pos, player.W).z);
            prog.setUniform("worldMatrix", mul(axisRotation(new vec3(1, 0, 0), 180), axisRotation(new vec3(0, 1, 0), carAngle), 
                axisRotation(new vec3(0, 1, 0), (float)player.turnDegrees), scaling(new vec3(.3, .3, .3)), translation(mul((float)-player.turnDegrees, player.U)),
                translation(nitroPos)));
            prog.setUniform("mode", 7);
            nitro.draw(prog);
        }
        if(shielded)
        {
            prog.setUniform("mode", 9);
            prog.setUniform("worldMatrix", mul(scaling(new vec3(0.5, 0.5, 0.5)), translation(player.pos)));
            shield.draw(prog);
        }
        return nitroFrame;
    }
    
    public static void draw_player_with_projected_shadows(Program prog, Player player, mat4 viewMatrix, mat4 shadowMatrix)
    {
        prog.setUniform("viewMatrix", shadowMatrix);
        prog.setUniform("mode", 5);
        glDepthMask(false);
        glStencilOp(GL_KEEP, GL_KEEP, GL_INCR);
        glStencilFunc(GL_EQUAL, 1, ~0);
        player.draw(prog);
        glDepthMask(true);
        glStencilFunc(GL_ALWAYS, 1, ~0);
        glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
        prog.setUniform("viewMatrix", viewMatrix);
    }
    
    public static void draw_to_shadow_buffer(Program shadowbufferprog, Camera cam,
                                             Player player, Mesh ground, ArrayList enemies,
                                             ArrayList bullets)
    {
        shadowbufferprog.use();
        cam.eye = new vec4(50, 50, 50, 1);
        cam.draw(shadowbufferprog);
        shadowbufferprog.setUniform("hitheryon", new vec3(cam.hither, cam.yon, (cam.yon - cam.hither)));
        player.draw(shadowbufferprog);
        shadowbufferprog.setUniform("worldMatrix", translation(new vec3(0, -.15, 0)));
        ground.draw(shadowbufferprog);
        Iterator<Enemy> enit = enemies.iterator();
        while(enit.hasNext())
        {
            Enemy en = enit.next();
            en.draw(shadowbufferprog);
        }
        Iterator<Bullet> buit = bullets.iterator();
        while(buit.hasNext())
        {
            Bullet bu = buit.next();
            bu.draw(shadowbufferprog);
        }
    }
    
    public static void draw_shadows(Program shadowprog, Framebuffer shadowBuffer, Camera cam, Player player,
                                    Mesh ground, ArrayList enemies, ArrayList bullets)
    {
        shadowprog.use();
        shadowprog.setUniform("lighthitheryon", new vec3(cam.hither, cam.yon, (cam.yon - cam.hither)));
        shadowprog.setUniform("lightPos", new vec4(50, 50, 50, 1));
        shadowprog.setUniform("light_viewMatrix", cam.viewMatrix);
        shadowprog.setUniform("light_projMatrix", cam.projMatrix);
        shadowprog.setUniform("shadowbuffer", shadowBuffer.texture);

        Functions.fixCamEyeToPlayer(cam, player);

        cam.draw(shadowprog);
        player.draw(shadowprog);
        shadowprog.setUniform("worldMatrix", translation(new vec3(0, -.15, 0)));
        ground.draw(shadowprog);
        Iterator<Enemy> enit = enemies.iterator();
        while(enit.hasNext())
        {
            Enemy en = enit.next();
            en.draw(shadowprog);
        }
    }
    
    public static float rand_rannge(float min, float max)
    {
        float random_num = min + R.nextFloat() * (max - min);
        if(random_num > max)
        {
            random_num = max;
        }
        return random_num;
    }
}
