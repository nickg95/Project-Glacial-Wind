package framework;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import static JGL.JGL.*;
import framework.math3d.vec3;
import framework.math3d.vec4;

public class ParticleSystem 
{
    int num_particles;
    int vao;
    int type;
    Texture2D texture;
    vec3 position;
    float ptimer;
    float alpha;
    
    public ParticleSystem(int size, int t, String texture_filename, vec3 pos)
    {
        num_particles = size;
        type = t;
        texture = new ImageTexture(texture_filename);
        position = pos;
        ptimer = 0;
        alpha = 1.0f;
        
        ByteBuffer bb = ByteBuffer.allocate(num_particles * 3 * 4);
        bb.order(ByteOrder.nativeOrder());
        float[] data = new float[num_particles * 3];
        if(type == 0)
        {
            for(int i = 0; i < num_particles; i++)
            {
                data[i * 3] = Functions.rand_rannge((float) -3, (float) 3);
                data[i * 3 + 1] = Functions.rand_rannge((float) 1, (float) 6);
                data[i * 3 + 2] = Functions.rand_rannge((float) -3, (float) 3);
            }
        }
        else if(type == 2)
        {
            for(int i = 0; i < num_particles; i++)
            {
                data[i * 3] = Functions.rand_rannge((float) -5, (float) 5);
                data[i * 3 + 1] = Functions.rand_rannge((float) 1, (float) 10);
                data[i * 3 + 2] = Functions.rand_rannge((float) -5, (float) 5);
            }
        }
        else
        {
             for(int i = 0; i < num_particles; i++)
            {
                data[i * 3] = Functions.rand_rannge((float) -2, (float) 2);
                data[i * 3 + 1] = Functions.rand_rannge((float) -2, (float) 2);
                data[i * 3 + 2] = Functions.rand_rannge((float) -2, (float) 2);
            }
        }
        bb.asFloatBuffer().put(data);
        byte[] bdata = bb.array();
        
        int[] temp = new int[1];
        glGenVertexArrays(1, temp);
        this.vao = temp[0];
        glBindVertexArray(vao);
        glGenBuffers(1, temp);
        int vbuff = temp[0];
        glBindBuffer(GL_ARRAY_BUFFER, vbuff);
        glBufferData(GL_ARRAY_BUFFER, bdata.length, bdata, GL_STATIC_DRAW);
        glEnableVertexAttribArray(Program.POSITION_INDEX);
        glVertexAttribPointer(Program.POSITION_INDEX, 3, GL_FLOAT, false, 3*4, 0);
        glBindVertexArray(0);
    }
    
    public void draw(Program prog, float elapsed)
    {
        vec4 gravity = new vec4(0, -9.81, 0, 0);
        prog.setUniform("p_texture", this.texture);
        prog.setUniform("a", gravity);
        prog.setUniform("initial_pos", position);
        
        glBindVertexArray(this.vao);
        glDrawArrays(GL_POINTS, 0, num_particles);
    }
}
