package framework;

import framework.math3d.mat4;
import framework.math3d.vec4;
import static framework.math3d.math3d.*;
import framework.math3d.vec3;

public class Water 
{
    UnitSquare mesh;
    mat4 scale;
    mat4 rotate;
    mat4 translate;
    vec4 pos;
    
    public Water(vec4 p)
    {
        mesh = new UnitSquare();
        pos = p;
        scale = scaling(10, 1, 10);
        rotate = axisRotation(new vec3(1, 0, 0), Math.PI/2);
        translate = translation(new vec3(0, -1, 0));
    }
    
    public void draw (Program prog)
    {
        prog.setUniform("worldMatrix", mul(rotate, scale, translate));
        mesh.draw(prog);
    }
}
