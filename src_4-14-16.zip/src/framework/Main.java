package framework;

import framework.math3d.vec3;
import framework.math3d.mat4;
import java.util.Set;
import java.util.TreeSet;
import static JGL.JGL.*;
import static JSDL.JSDL.*;
import static framework.math3d.math3d.*;
import framework.math3d.vec2;
import framework.math3d.vec4;
import static java.lang.Math.atan2;
import static java.lang.Math.toDegrees;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.TreeMap;

public class Main
{
        
    public static void main(String[] args)
    {
        
        // SDL SETUP
        SDL_Init(SDL_INIT_VIDEO);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK,SDL_GL_CONTEXT_PROFILE_CORE);
        SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE,24);
        SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE,8);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION,3);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION,2);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, SDL_GL_CONTEXT_DEBUG_FLAG);
        long win = SDL_CreateWindow("ETGG 2802",40,60, 1024, 1000, SDL_WINDOW_OPENGL );
        SDL_GL_CreateContext(win);
        
        glDebugMessageControl(GL_DONT_CARE,GL_DONT_CARE,GL_DONT_CARE, 0,null, true );
        glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);
        glDebugMessageCallback(
                (int source, int type, int id, int severity, String message, Object obj ) -> {
                    //System.out.println("GL message: "+message);
                    //if( severity == GL_DEBUG_SEVERITY_HIGH )
                    //    System.exit(1);
                },
                null);

        int[] tmp = new int[1];
        glGenVertexArrays(1,tmp);
        int vao = tmp[0];
        glBindVertexArray(vao);

        glClearColor(0.2f,0.4f,0.6f,1.0f);
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        
        glEnable(GL_STENCIL_TEST);

        // VARIABLES
        Set<Integer> keys = new TreeSet<>();
        Grid grid;
        Random rand = new Random();
        Camera cam;
        Program prog, blurprog, skyprog, particleprog, waterprog, distbufferprog;
        float prev, last_bullet_time, bulletVel, hitTimer, speedBoostTimer, flashTimer, rapidFireTimer, fireRate, pauseTimer, carAngle;
        float wave1Timer, wave2Timer, wave3Timer, wave4Timer, shieldTimer;
        Mesh ground, car, playerMesh, wheel, pBulletMesh, eBulletMesh, healthbg, boostbg, healthseg, boostseg, gameover, pauseScreen;
        Mesh boostpowerup, healthpowerup, speedpowerup, rapidfire, shieldpowerup, nitro, wave1, wave2, wave3, wave4, explosion, shield, skybox;
        Mesh tank;
        ArrayList<Bullet> bullets;
        ArrayList<Enemy> enemies;
        ArrayList<PowerUp> powerups;
        ArrayList<ParticleSystem> explosions;
        Player player;
        Bar healthbar, boostbar;
        int health, numBullets, nitroFrame, currWave;
        boolean bulletFired, boosting, boostCharging, speedUpgraded, rapidFire, paused, shielded;
        UnitSquare usq;
        vec4 groundNormal, groundPoint;
        vec3 nitroPos;
        float A, B, C, x, y, z, D;
        mat4 T, M, T1, F, viewMatrix, shadowMatrix, nitroTranslate;
        String[] skytextures;
        Water water;
        Framebuffer fbo1, fbo2, fbo3, objDistBuffer, planarRefBuffer;
        
        // INITIALIZATIONS
        Texture2D dummytex = new SolidTexture(GL_UNSIGNED_BYTE,0,0,0,0);
       
        float ptimer = 0;
        grid = new Grid(-150, 150, -150, 150, 1);
        skytextures = new String[6];
        skytextures[0] = "assets/skybox/skyposx.png";
        skytextures[1] = "assets/skybox/skynegx.png";
        skytextures[2] = "assets/skybox/skyposy.png";
        skytextures[3] = "assets/skybox/skynegy.png";
        skytextures[4] = "assets/skybox/skyposz.png";
        skytextures[5] = "assets/skybox/skynegz.png";
        ground = new Mesh("assets/ground256.obj.mesh", "assets/grass.png");
        car = new Mesh("assets/carbody.obj.mesh", "");
        playerMesh = new Mesh("assets/carbody.obj.mesh", "assets/playercar.png");
        wheel = new Mesh("assets/wheel.obj.mesh", "");
        pBulletMesh = new Mesh("assets/usq.obj.mesh", "assets/nova.png");
        eBulletMesh = new Mesh("assets/usq.obj.mesh", "assets/nova2.png"); //Orange bullet texture taken from: http://www.userlogos.org/background/macleodmac/01272009/starburst-v10
        healthbg = new Mesh("assets/usq.obj.mesh", "assets/health.png");
        boostbg = new Mesh("assets/usq.obj.mesh", "assets/boost.png");
        healthseg = new Mesh("assets/usq.obj.mesh", "assets/healthsegment.png");
        boostseg = new Mesh("assets/usq.obj.mesh", "assets/boosttexture.png");
        gameover = new Mesh("assets/usq.obj.mesh", "assets/gameover.png");
        pauseScreen = new Mesh("assets/usq.obj.mesh", "assets/paused.png");
        boostpowerup = new Mesh("assets/usq.obj.mesh", "assets/boostpowerup.png");
        healthpowerup = new Mesh("assets/usq.obj.mesh", "assets/healthpowerup.png");
        speedpowerup = new Mesh("assets/usq.obj.mesh", "assets/speedpowerup.png");
        rapidfire = new Mesh("assets/usq.obj.mesh", "assets/rapidfire.png");
        shieldpowerup = new Mesh("assets/usq.obj.mesh", "assets/shieldpowerup.png");
        nitro = new Mesh("assets/usq.obj.mesh", "assets/flame.png"); //Flame texture taken from: http://www.cs.vu.nl/~eliens/hush/archive/wt/sdk/training/TextureAnimationHowTo/
        wave1 = new Mesh("assets/usq.obj.mesh", "assets/wave1.png");
        wave2 = new Mesh("assets/usq.obj.mesh", "assets/wave2.png");
        wave3 = new Mesh("assets/usq.obj.mesh", "assets/wave3.png");
        wave4 = new Mesh("assets/usq.obj.mesh", "assets/wave4.png");
        //explosion = new Mesh("assets/usq.obj.mesh", "assets/explosion_opaque.png"); //Explosion texture taken from: http://www.nordenfelt-thegame.com/blog/tag/graphics/page/2/
        tank = new Mesh("assets/tank.obj.mesh", "assets/tank.png");
        shield = new Mesh("assets/sphere.obj.mesh", "assets/shieldtexture.png");
        skybox = new Mesh("assets/cube.obj.mesh", skytextures);
        bullets = new ArrayList<>();
        enemies = new ArrayList<>();
        powerups = new ArrayList<>();
        explosions = new ArrayList<>();
        player = new Player(new vec4(0, 0, -5, 1), playerMesh, wheel);
        numBullets = 0;
        bulletVel = 10;
        hitTimer = 0;
        speedBoostTimer = 0;
        flashTimer = 0;
        rapidFireTimer = 0;
        fireRate = 0.5f;
        pauseTimer = 0;
        carAngle = 0;
        nitroFrame = 0;
        wave1Timer = System.nanoTime()*1E-9f;
        wave2Timer = 0;
        wave3Timer = 0;
        wave4Timer = 0;
        shieldTimer = 0;
        currWave = 1;
        bulletFired = false;
        boosting = false;
        boostCharging = false;
        speedUpgraded = false;
        rapidFire = false;
        paused = false;
        shielded = false;
        last_bullet_time = 0;
        healthbar = new Bar(new vec4(-.8, .85, .1, 1), healthbg, healthseg);
        boostbar = new Bar(new vec4(.2, .85, .1, 1), boostbg, boostseg);
        health = 10;
        nitroPos = new vec3(sub(player.pos, player.W).x, sub(player.pos, player.W).y+.2f, sub(player.pos, player.W).z);
        nitroTranslate = mat4.identity();
        water = new Water(new vec4(player.pos.x, player.pos.y, player.pos.z, 1));
        usq = new UnitSquare();
        
        // FLATTEN MATRIX FOR SHADOWS
        groundNormal = new vec4(0, 1, 0, 0);
        A = groundNormal.x;
        B = groundNormal.y;
        C = groundNormal.z;
        groundPoint = new vec4(0, 0, 0, 1);
        x = groundPoint.x - 50;
        y = groundPoint.y - 50;
        z = groundPoint.z - 50;
        D = -((A*x)+(B*y)+(C*z));
        T = translation(new vec3(-50, -50, -50));
        T1 = translation(new vec3(50, 50, 50));
        M = new mat4(-D, 0, 0, A, 0, -D, 0, B, 0, 0, -D, C, 0, 0, 0, 0);
        F = mul(T, M);
        F = mul(F, T1);

        fbo1 = new Framebuffer(512,512);
        fbo2 = new Framebuffer(512,512);
        fbo3 = new Framebuffer(512,512);
        objDistBuffer = new Framebuffer(512, 512, GL_RGBA32F, GL_FLOAT);
        planarRefBuffer = new Framebuffer(512, 512);

        prog = new Program("shaders/vs.txt","shaders/fs.txt");
        blurprog = new Program("shaders/blurvs.txt","shaders/blurfs.txt");
        skyprog = new Program("shaders/skyvs.txt", "shaders/skyfs.txt");
        particleprog = new Program("shaders/particlevs.txt", "shaders/particlegs.txt", "shaders/particlefs.txt");
        waterprog = new Program("shaders/watervs.txt", "shaders/waterfs.txt");
        distbufferprog = new Program("shaders/shadowbuffervs.txt", "shaders/shadowbufferfs.txt");

        // DISTANCE FROM CAM TO PLAYER
        cam = new Camera(new vec4(player.pos.x, player.pos.y + 0.5, player.pos.z - 1, 1));
        vec4 origV = new vec4(sub(cam.eye, player.pos));
        float dist = length(origV);
        
        // SPAWN INITIAL WAVE
        Wave waveOne = new Wave(currWave);
        waveOne.spawnEnemies(enemies, car, wheel, tank);
        
        // SPAWN POWERUPS
        for(int i = 0; i < 100; i++)
        {
            for(int j = 0; j < 100; j++)
            {
                if(i % 10 == 0 && j % 10 == 0)
                {
                    Mesh mesh;
                    int r = rand.nextInt(2);
                    int t = rand.nextInt(5);
                    if(r == 0)
                    {
                        switch(t)
                        {
                            case(0):
                                mesh = boostpowerup;
                                break;
                            case(1):
                                mesh = healthpowerup;
                                break;
                            case(2):
                                mesh = speedpowerup;
                                break;
                            case(3):
                                mesh = rapidfire;
                                break;
                            default:
                                mesh = shieldpowerup;
                                break;
                        }
                        PowerUp p = new PowerUp(new vec4(i, 0, j, 1), t, mesh);
                        p.gridCell = grid.put(p.pos.x, p.pos.z, p, p.gridCell);
                        powerups.add(p);
                    }
                }
            }
        }
        
        prev = (float)(System.nanoTime()*1E-9);

        SDL_Event ev=new SDL_Event();
        while(true){
            while(true){
                int rv = SDL_PollEvent(ev);
                if( rv == 0 )
                    break;
                //System.out.println("Event "+ev.type);
                if( ev.type == SDL_QUIT )
                    System.exit(0);
                if( ev.type == SDL_MOUSEMOTION ){
                    //System.out.println("Mouse motion "+ev.motion.x+" "+ev.motion.y+" "+ev.motion.xrel+" "+ev.motion.yrel);
                }
                if( ev.type == SDL_KEYDOWN ){
                    //System.out.println("Key press "+ev.key.keysym.sym+" "+ev.key.keysym.sym);
                    keys.add(ev.key.keysym.sym);
                }
                if( ev.type == SDL_KEYUP ){
                    keys.remove(ev.key.keysym.sym);
                }
            }

            // TIMER
            float now = (float)(System.nanoTime()*1E-9);
            float elapsed = 0;
            if(health > 0 && !paused)
                elapsed = now-prev;
            
            // SET CAM EYE
            vec4 newV = Functions.fixCamEyeToPlayer(cam, player);
            vec4 eyePos = cam.eye;

            prev=now;
            
            // SET BULLET VEL
            if(boosting)
                bulletVel = 20;
            else
                bulletVel = 10;
            
            if(rapidFire)
                fireRate = .1f;
            else
                fireRate = .5f;
            
            // SET PLAYER GRID CELL
            player.gridCell = grid.put(player.pos.x, player.pos.z, player, player.gridCell);

            // KEYBOARD INPUT/DRIVING MATH
            // VARIABLES REFERENCE GUIDE:
            // wheelSpin: The rate that the car wheels spin around the x-axis as the car drives
            // newV/dist: The distance between the cam and the player
            // steering: The rotation of the front wheels around the y-axis -- turns the front wheels when the car turns
            // axisChange: Used in the compute_axis_matrix method of the Player class -- represents the amount that the car is turning by in this frame
            // carAngle: Represents the overall car's angle of rotation around the y-axis -- used to determine how much to rotate the nitro effect by
            // wheelRotation: The x-rotation matrix of the wheels -- rotates the wheels around the x-axis by wheelSpin when the car drives
            // turnDegrees: The amount to rotate the car by for its second rotation -- rotates twice, once to rotate the axes and again to turn the car body slightly further
            // nitroTranslate: The translation matrix that centers the nitro effect behind the car
            // player.velocity: The player's speed, all physics calulations are done in the Player class
            // player.slow(): Called when not driving to gradually slow car down to a stop
            
            if( keys.contains(SDLK_w) && !keys.contains(SDLK_s))
            {
                if(!boosting && !speedUpgraded)
                {
                    player.drive(elapsed, 0);
                    player.wheelSpin += elapsed * player.velocity;
                    //if(length(newV) >= dist)
                        cam.eye = add(cam.eye, mul(player.W, elapsed*player.velocity));
                }
                else if(boosting && !speedUpgraded || !boosting && speedUpgraded)
                {
                    player.drive(elapsed*2, 0);
                    player.wheelSpin += elapsed * (player.velocity*2);
                    //if(length(newV) >= dist)
                        cam.eye = add(cam.eye, mul(player.W, elapsed*(player.velocity*2)));
                }
                else if(boosting && speedUpgraded)
                {
                    player.drive(elapsed*3, 0);
                    player.wheelSpin += elapsed * (player.velocity*3);
                    //if(length(newV) >= dist)
                        cam.eye = add(cam.eye, mul(player.W, elapsed*(player.velocity*3)));
                }
                player.compute_axis_matrix(elapsed);
            }
            if( keys.contains(SDLK_s) && !keys.contains(SDLK_w))
            {
                if(length(newV) >= dist)
                    cam.eye = add(cam.eye, mul(player.W, +elapsed*player.velocity));
                player.drive(elapsed, 1);
                player.wheelSpin += elapsed * player.velocity;
                player.compute_axis_matrix(elapsed);
            }
            if(player.velocity > 0 && !keys.contains(SDLK_w) && !keys.contains(SDLK_s))
            {
                player.slow(elapsed, 0);
                cam.eye = add(cam.eye, mul(player.W, elapsed*player.velocity));
            }
            if(player.velocity > -0.2f && player.velocity < 0.0f)
                player.velocity = 0.0f;
            else if(player.velocity < 0 && !keys.contains(SDLK_w) && !keys.contains(SDLK_s))
            {
                player.slow(elapsed, 1);
                cam.eye = add(cam.eye, mul(player.W, elapsed*player.velocity));
            }
            if( keys.contains(SDLK_a))
            {
                player.steering = (float) 0.4;
                if(keys.contains(SDLK_w) && !keys.contains(SDLK_s))
                {
                    player.axisChange = (float) 0.8;
                    carAngle += .8f * elapsed;
                    if(player.turnDegrees < .4)
                        player.turnDegrees += elapsed * .6;
                }
                else if(keys.contains(SDLK_s) && !keys.contains(SDLK_w))
                {
                    player.axisChange = (float) 0.8;
                    carAngle += .8f * elapsed;
                    if(player.turnDegrees < .4)
                        player.turnDegrees += elapsed * .6;
                }
            }
            else if( keys.contains(SDLK_d))
            {
                player.steering = (float) -0.4;
                if(keys.contains(SDLK_w) && !keys.contains(SDLK_s))
                {
                    player.axisChange = (float) -0.8;
                    carAngle -= .8f * elapsed;
                    if(player.turnDegrees > -.4)
                        player.turnDegrees -= elapsed * .6;
                }
                else if(keys.contains(SDLK_s) && !keys.contains(SDLK_w))
                {
                    player.axisChange = (float) -0.8;
                    carAngle -= .8f * elapsed;
                    if(player.turnDegrees > -.4)
                        player.turnDegrees -= elapsed * .6;
                }
            }
            else if((keys.contains(SDLK_w) || keys.contains(SDLK_s)) && (!keys.contains(SDLK_w) || !keys.contains(SDLK_s)))
            {
                if(player.axisChange < -.004)
                {
                    player.axisChange += elapsed * .8;
                }
                else if(player.axisChange > .004)
                {
                    player.axisChange -= elapsed * .8;
                }
                player.wheelRotation = mat4.identity();
                if(player.turnDegrees != 0 )
                {
                    player.axisChange = player.turnDegrees;
                    if(keys.contains(SDLK_w) || keys.contains(SDLK_s))
                    {
                        if(player.turnDegrees < 0.0f)
                        {
                            player.turnDegrees += elapsed * .4;
                            carAngle -= .2f * elapsed;
                            nitroTranslate = translation(mul(.2f, player.U));
                        }
                        else if(player.turnDegrees > 0.0f)
                        {
                            player.turnDegrees -= elapsed * .4;
                            carAngle += .2f * elapsed;
                            nitroTranslate = translation(mul(.2f, player.U));
                        }
                    }
                }
            }
            
            if(player.turnDegrees < 0.05f && player.turnDegrees > -0.05f && !keys.contains(SDLK_a) && !keys.contains(SDLK_d))
            {
                player.turnDegrees = 0.0f;
            }
            if(player.turnDegrees < 0.4 && player.turnDegrees > 0.395)
            {
                player.turnDegrees = 0.4f;
            }
            if(player.turnDegrees > -0.4 && player.turnDegrees < -0.395)
            {
                player.turnDegrees = -0.4f;
            }

            // SETS LEVEL BOUNDARIES
            if(player.pos.x >= 80)
                player.pos.x = 80;
            else if(player.pos.x <= -80)
                player.pos.x = -80;
            if(player.pos.z >= 90)
                player.pos.z = 90;
            else if(player.pos.z <= -80)
                player.pos.z = -80;
            
            // OTHER KEYBOARD INPUT -- BULLET FIRING, BOOSTING, PAUSING
            if(keys.contains(SDLK_SPACE) && bulletFired == false && last_bullet_time < now - fireRate)
            {
                Bullet bullet = new Bullet(player.pos , player.W, bulletVel, 3, true, 0, pBulletMesh);
                bullets.add(bullet);
                numBullets += 1;
                bulletFired = true;
                last_bullet_time = now;
            }
            if(!keys.contains(SDLK_SPACE))
                bulletFired = false;
            if(keys.contains(SDLK_b) && keys.contains(SDLK_w) && !keys.contains(SDLK_s )&& !boostCharging && !paused)
                boosting = true;
            else
                boosting = false;
            if(keys.contains(SDLK_p))
            {
                if(paused && pauseTimer < now - 0.5)
                {
                    paused = false;
                    pauseTimer = now;
                }
                else if(!paused && pauseTimer < now - 0.5)
                {
                    paused = true;
                    pauseTimer = now;
                }
            }
            
            // WATER REFLECTION
            mat4 R = new mat4(1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
            planarRefBuffer.bind();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            prog.use();
            prog.setUniform("lightPos",new vec3(50,50,50) );
            prog.setUniform("mode", 1);
            prog.setUniform("worldMatrix", translation(new vec3(0, -.25, 0)));
            ground.draw(prog);
            cam.drawReflection(prog, R);
            prog.setUniform("mode", 0);
            prog.setUniform("mode", 0);
            player.draw(prog);
            player.update(elapsed);
            Iterator<Enemy> eIt = enemies.iterator();
            while(eIt.hasNext())
            {
                eIt.next().draw(prog);
            }
            if(boosting)
            {
                if(nitroFrame == 15)
                    nitroFrame = 0;
                else
                    nitroFrame++;
                int col = (nitroFrame % 4);
                int row = 3 - (nitroFrame / 4);
                mat4 textureMatrix = mul(scaling(new vec3(.25, .25, 1)), translation(col*.25f, row*.25f, 0));
                prog.setUniform("textureMatrix", textureMatrix);
                mat4 nitroU;
                if(player.turnDegrees > 0.1 || player.turnDegrees < -0.1)
                {
                    nitroU = translation(mul(-player.turnDegrees, player.U));
                }
                else
                {
                    nitroU = mat4.identity();
                }
                prog.setUniform("worldMatrix", mul(axisRotation(new vec3(1, 0, 0), 180),
                        scaling(new vec3(1.7, 2, 2)), player.carWorld, translation(new vec3(0, .3, 0)),
                        translation(mul(1.2, player.W.neg())), nitroU));
                prog.setUniform("mode", 7);
                nitro.draw(prog);
            }
            if(shielded)
            {
                prog.setUniform("mode", 9);
                prog.setUniform("worldMatrix", mul(scaling(new vec3(0.5, 0.5, 0.5)), translation(player.pos)));
                shield.draw(prog);
            }
            Iterator<Bullet> bIt = bullets.iterator();
            while(bIt.hasNext())
            {
                Bullet b = bIt.next();
                prog.setUniform("cameraU", player.U);
                prog.setUniform("cameraV", player.V);
                prog.setUniform("mode", 2);
                b.draw(prog);
            }
            planarRefBuffer.unbind();
            
            // GET OBJECT DIST
            objDistBuffer.bind();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            distbufferprog.use();
            cam.draw(distbufferprog);
            distbufferprog.setUniform("hitheryon", new vec3(1, 100, (99)));
            distbufferprog.setUniform("worldMatrix", translation(new vec3(0, -.25, 0)));
            ground.draw(distbufferprog);
            objDistBuffer.unbind();
            
            // FIRST DRAWING PASS - DRAWS SCENE UNALTERED TO FBO1
            fbo1.bind();
            //DRAW SKY
            glClearColor(0.2f,0.4f,0.6f,1.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            skyprog.use();
            cam.draw(skyprog);
            skyprog.setUniform("worldMatrix", translation(eyePos)); // Used eyePos instead of cam.eye to avoid jittering (doesn't account for slight camera changes when driving)
            skybox.draw(skyprog);
            // DRAW REST OF SCENE
            prog.use();
            glStencilFunc(GL_ALWAYS, 1, ~0);
            glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
            prog.use();
            prog.setUniform("lightPos",new vec3(50,50,50) );
            
            vec3 eye3 = new vec3(cam.eye.x, cam.eye.y, cam.eye.z);
            vec3 carPos3 = new vec3(player.pos.x, player.pos.y, player.pos.z);
            vec3 up = new vec3(0, 1, 0);
            cam.lookAt(eye3, carPos3, up);
            prog.setUniform("mode", 0);
            cam.draw(prog);
            prog.setUniform("mode", 0);
            player.draw(prog);
            player.update(elapsed);
            if(boosting)
            {
                if(nitroFrame == 15)
                    nitroFrame = 0;
                else
                    nitroFrame++;
                int col = (nitroFrame % 4);
                int row = 3 - (nitroFrame / 4);
                mat4 textureMatrix = mul(scaling(new vec3(.25, .25, 1)), translation(col*.25f, row*.25f, 0));
                prog.setUniform("textureMatrix", textureMatrix);
                mat4 nitroU;
                if(player.turnDegrees > 0.1 || player.turnDegrees < -0.1)
                {
                    nitroU = translation(mul(-player.turnDegrees, player.U));
                }
                else
                {
                    nitroU = mat4.identity();
                }
                prog.setUniform("worldMatrix", mul(axisRotation(new vec3(1, 0, 0), 180),
                        scaling(new vec3(1.7, 2, 2)), player.carWorld, translation(new vec3(0, .3, 0)),
                        translation(mul(1.2, player.W.neg())), nitroU));
                prog.setUniform("mode", 7);
                System.out.println(player.turnDegrees);
                nitro.draw(prog);
            }
            if(shielded)
            {
                prog.setUniform("mode", 9);
                prog.setUniform("worldMatrix", mul(scaling(new vec3(0.5, 0.5, 0.5)), translation(player.pos)));
                shield.draw(prog);
            }
            prog.setUniform("mode", 1);
            prog.setUniform("worldMatrix", translation(new vec3(0, -.25, 0)));
            glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
            ground.draw(prog);
            
            // SECOND DRAWING PASS - DRAWS SHADOWS, STILL DRAWS TO FBO1
            
            viewMatrix = cam.viewMatrix;
            shadowMatrix = mul(F, viewMatrix).negate();
            prog.setUniform("viewMatrix", shadowMatrix);
            prog.setUniform("mode", 5);
            glDepthMask(false);
            glStencilOp(GL_KEEP, GL_KEEP, GL_INCR);
            glStencilFunc(GL_EQUAL, 1, ~0);
            player.draw(prog);
            glDepthMask(true);
            glStencilFunc(GL_ALWAYS, 1, ~0);
            glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
            prog.setUniform("viewMatrix", viewMatrix);
            
            // ITERATES THROUGH POWERUPS, SETS POWERUP EFFECTS
            Iterator<PowerUp> iterator = powerups.iterator();
            while(iterator.hasNext())
            {
                PowerUp p = iterator.next();
                p.draw(prog);
                ArrayList<int[]> nb = grid.getNeighbors(p.gridCell);
                Iterator nIterator = nb.iterator();
                while(nIterator.hasNext())
                {
                    int[] cell = (int[]) nIterator.next();
                    TreeMap i = (TreeMap) grid.G.get(cell[0]);
                    ArrayList bucket = (ArrayList) i.get(cell[1]);
                    Iterator bIter = bucket.iterator();
                    while(bIter.hasNext())
                    {
                        Object n = bIter.next();
                        if(n.equals(player))
                        {
                            vec4 v = sub(p.pos, player.pos);
                            if(length(v) <= 1 && p.type == PowerUp.SPEED)
                            {
                                speedUpgraded = true;
                                speedBoostTimer = now + 3;
                                iterator.remove();
                            }
                            else if(length(v) <= 1 && p.type == PowerUp.BOOST && boostbar.barlength < .3f)
                            {
                                boostbar.barlength = .3f;
                                iterator.remove();
                            }
                            else if(length(v) <= 1 && p.type == PowerUp.HEALTH && health < 10)
                            {
                                if(health <= 8)
                                {
                                    health += 2;
                                    healthbar.barlength += .06;
                                    iterator.remove();
                                }
                                else if(health == 9)
                                {
                                    health++;
                                    healthbar.barlength += .03;
                                    iterator.remove();
                                }
                            }
                            else if(length(v) <= 1 && p.type == PowerUp.RAPIDFIRE)
                            {
                                rapidFire = true;
                                rapidFireTimer = now + 3;
                                iterator.remove();
                            }
                            else if(length(v) <= 1 && p.type == PowerUp.SHIELD)
                            {
                                shielded = true;
                                shieldTimer = now + 3;
                                iterator.remove();
                            }
                        }
                    }
                }
            }
            
            // STARTS NEW WAVE IF ALL ENEMIES ARE DEFEATED
            if(enemies.isEmpty())
            {
                currWave++;
                Wave newWave = new Wave(currWave);
                newWave.spawnEnemies(enemies, car, wheel, tank);
                switch (currWave) {
                    case 2:
                        wave2Timer = System.nanoTime()*1E-9f;
                        break;
                    case 3:
                        wave3Timer = System.nanoTime()*1E-9f;
                        break;
                    case 4:
                        wave4Timer = System.nanoTime()*1E-9f;
                        break;
                    default:
                        break;
                }
            }
            
            // ITERATES THROUGH ENEMIES
            Iterator<Enemy> it = enemies.iterator();
            while(it.hasNext())
            {
                Enemy e = it.next();
                e.gridCell = grid.put(e.pos.x, e.pos.z, e, e.gridCell);
                e.update(elapsed);
                if(e.alpha <= 0.0)
                    it.remove();
                if(e.type == 0)
                {
                    e.drive(elapsed * 2);
                    e.wheelSpin += elapsed * 5;
                }
                else if(e.type == 1)
                {
                    e.drive(elapsed);
                }
                // ENEMIES FIRST DRAWING PASS
                prog.setUniform("mode", 0);
                e.draw(prog);
                // ENEMIES SECOND DRAWING PASS (SHADOWS)
                prog.setUniform("viewMatrix", shadowMatrix);
                prog.setUniform("mode", 5);
                glStencilOp(GL_KEEP, GL_KEEP, GL_INCR);
                glStencilFunc(GL_EQUAL, 1, ~0);
                glDepthMask(false);
                e.draw(prog);
                glDepthMask(true);
                glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
                glStencilFunc(GL_ALWAYS, 1, ~0);
                prog.setUniform("viewMatrix", viewMatrix);
                // SETS LEVEL BOUNDARIES
                if(e.pos.x >= 80)
                    e.pos.x = 80;
                else if(e.pos.x <= -80)
                    e.pos.x = -0;
                if(e.pos.z >= 90)
                    e.pos.z = 90;
                else if(e.pos.z <= -80)
                    e.pos.z = -80;
                // FIRES BULLETS
                if(e.bulletTimer <= now - 3)
                {
                    if(e.type == 0)
                    {
                        bullets.add(new Bullet(e.pos, e.W, 10, 3, false, 0, eBulletMesh));            
                    }
                    else if(e.type == 1)
                    {
                        Bullet b = new Bullet(new vec4(e.pos.x+1, e.pos.y+.45f, e.pos.z, 1), e.U, 10, 3, false, 1, eBulletMesh);
                        bullets.add(b);
                    }
                    numBullets++;
                    e.bulletTimer = now;
                }

                // TURNING AI
                float angle = 0;
                vec4 a = sub(player.pos, e.pos);
                vec4 b = e.W;
                if(e.type == 1)
                {
                    b = e.U;
                }
                float theta = (float) atan2(a.z, a.x);
                float phi = (float) atan2(b.z, b.x);
                theta = (float) toDegrees(theta);
                phi = (float) toDegrees(phi);
                angle = phi - theta;
                if(angle < 0)
                {
                    e.turn((float) (-elapsed*.5));
                    e.steering = (float) -0.4;
                }
                else
                {
                    e.turn((float) (elapsed*.5));
                    e.steering = (float) 0.4;
                }

                // HIT DETECTION WITH PLAYER
                ArrayList<int[]> nb = grid.getNeighbors(e.gridCell);
                Iterator nIterator = nb.iterator();
                while(nIterator.hasNext())
                {
                    int[] cell = (int[]) nIterator.next();
                    TreeMap i = (TreeMap) grid.G.get(cell[0]);
                    ArrayList bucket = (ArrayList) i.get(cell[1]);
                    Iterator bIter = bucket.iterator();
                    while(bIter.hasNext())
                    {
                        Object n = bIter.next();
                        if(n.equals(player))
                        {
                            if(e.circle.hit(player.circle) && !shielded && hitTimer < now && health >= 1 && !paused)
                            {
                                healthbar.barlength -= .03;
                                health -= 1;
                                player.gotHit = true;
                                hitTimer = now + 1;
                            }
                        }
                    }
                }
            }
            
            // REMOVES BULLETS
            if(numBullets > 0)
            {
                Iterator<Bullet> i = bullets.iterator();
                Bullet bullet = i.next();
                if(bullet.alpha <= 0)
                {
                    i.remove(); 
                    numBullets --;
                }
            }
            
            // ITERATES THROUGH BULLETS
            if(numBullets > 0)
            {
                Iterator<Bullet> iter = bullets.iterator();
                while(iter.hasNext())
                {
                    Bullet b = iter.next();
                    b.gridCell = grid.put(b.pos.x, b.pos.z, b, b.gridCell);
                    // BULLET HIT DETECTION
                    if(b.fromPlayer)
                    {
                        ArrayList<int[]> neighbors = grid.getNeighbors(b.gridCell);
                        Iterator<int[]> nIter = neighbors.iterator();
                        while(nIter.hasNext())
                        {
                            int[] cell = nIter.next();
                            TreeMap i = (TreeMap) grid.G.get(cell[0]);
                            ArrayList bucket = (ArrayList) i.get(cell[1]);
                            Iterator bIter = bucket.iterator();
                            while(bIter.hasNext())
                            {
                                Object n = bIter.next();
                                if(n instanceof Enemy)
                                {
                                    Enemy e = (Enemy) n;
                                    if(b.hit(e.circle))
                                    {
                                        try
                                        {
                                            iter.remove();
                                            numBullets --;
                                        }
                                        catch(IllegalStateException ex)
                                        {
                                            continue;
                                        }
                                        if(e.type == 0)
                                        {
                                            e.state = 1;
                                            vec3 po = new vec3(e.pos.x, e.pos.y, e.pos.z);
                                            ParticleSystem ex = new ParticleSystem(600, 0, "assets/fire.png", po);
                                            explosions.add(ex);
                                        }
                                        else if(e.type == 1)
                                        {
                                            explosions.add(new ParticleSystem(500, 0, "assets/fire.png", new vec3(e.pos.x, e.pos.y, e.pos.z)));
                                            e.health--;
                                            if(e.health == 0)
                                            {
                                                e.state = 1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        ArrayList<int[]> neighbors = grid.getNeighbors(b.gridCell);
                        Iterator<int[]> nIter = neighbors.iterator();
                        while(nIter.hasNext())
                        {
                            int[] cell = nIter.next();
                            TreeMap i = (TreeMap) grid.G.get(cell[0]);
                            ArrayList bucket = (ArrayList) i.get(cell[1]);
                            Iterator bIter = bucket.iterator();
                            while(bIter.hasNext())
                            {
                                Object n = bIter.next();
                                if(n.equals(player))
                                {
                                    if(b.hit(player.circle))
                                    {
                                        explosions.add(new ParticleSystem(100, 1, "assets/sparks.png", new vec3(b.pos.x, b.pos.y+.5, b.pos.z)));
                                        try
                                        {
                                            iter.remove();
                                            numBullets --;
                                        }
                                        catch(IllegalStateException ex)
                                        {
                                            continue;
                                        }
                                        if(health >= 1 && !paused && !shielded)
                                        {
                                            if(b.type == 0)
                                            {
                                                healthbar.barlength -= .03;
                                                health -= 1;
                                                player.gotHit = true;
                                                hitTimer = now + 1;
                                            }
                                            else if(b.type == 1)
                                            {
                                                healthbar.barlength -= .06;
                                                health -= 2;
                                                player.gotHit = true;
                                                hitTimer = now + 1;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    // BULLETS FIRST DRAWING PASS
                    prog.use();
                    cam.draw(prog);
                    b.update(elapsed, explosions, prog, player);
                    prog.setUniform("cameraU", player.U);
                    prog.setUniform("cameraV", player.V);
                    prog.setUniform("mode", 2);
                    b.draw(prog);
                    // BULLETS SECOND DRAWING PASS (SHADOWS)
                    prog.setUniform("viewMatrix", shadowMatrix);
                    prog.setUniform("mode", 6);
                    glDepthMask(false);
                    glStencilOp(GL_KEEP, GL_KEEP, GL_INCR);
                    glStencilFunc(GL_EQUAL, 1, ~0);
                    b.draw(prog);
                    glDepthMask(true);
                    glStencilFunc(GL_ALWAYS, 1, ~0);
                    glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
                    prog.setUniform("viewMatrix", viewMatrix);
                }
            }
            
            // DOES FLASH EFFECT IF PLAYER IS HIT
            if(player.gotHit && now < hitTimer)
            {
                if(player.state == 0 && flashTimer < now)
                {
                    player.state = 1;
                    flashTimer = now+.1f;
                }
                else if(player.state == 1 && flashTimer < now)
                {
                    player.state = 0;
                    flashTimer = now+.1f;
                }
            }
            else
                player.gotHit = false;
            
            // POWERUP STATES
            if(speedUpgraded && now > speedBoostTimer)
                speedUpgraded = false;
            if(rapidFire && now > rapidFireTimer)
                rapidFire = false;
            if(shielded && now > shieldTimer)
                shielded = false;
            
            // UPDATES BOOSTBAR LENGTH
            if(boosting && boostbar.barlength > 0 && keys.contains(SDLK_w))
            {
                if(boostbar.barlength < elapsed/4)
                    boostbar.barlength = 0;
                else
                    boostbar.barlength -= elapsed/4;
            }
            if(!boosting && boostbar.barlength < .3)
            {
                if(boostbar.barlength > .3-(elapsed/6))
                    boostbar.barlength = (float) .3;
                else
                    boostbar.barlength += elapsed/6;
            }
            if(boostbar.barlength == 0)
                boostCharging = true;
            if(boostCharging && boostbar.barlength == (float) .3)
                boostCharging = false;
            
            // DRAW PARTICLES
            particleprog.use();
            cam.draw(particleprog);
            Iterator<ParticleSystem> expit = explosions.iterator();
            while(expit.hasNext())
            {
                ParticleSystem e = expit.next();
                particleprog.setUniform("t", e.ptimer);
                particleprog.setUniform("alpha", e.alpha);
                e.draw(particleprog, elapsed);
                if(e.alpha <= 0.0f)
                {
                    expit.remove();
                }
                if(e.type == 0)
                {
                    e.ptimer += 0.02;
                    e.alpha -= 0.02;
                }
                else if(e.type == 1)
                {
                    e.ptimer += 0.01;
                    e.alpha -= 0.02;
                }
                else if(e.type == 2)
                {
                    e.ptimer += 0.01;
                    e.alpha -= 0.005;
                }
                
            }
            
            // SET STENCIL BUFFER FOR REFLECTION
            /*waterprog.use();
            glDepthMask(false);
            glColorMask(false, false, false, false);
            cam.draw(waterprog);
            glStencilFunc(GL_ALWAYS, 3, ~0);
            glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
            water.draw(waterprog);
            glDepthMask(true);
            glColorMask(true, true, true, true);*/
            
            // DRAW WATER REFLECTION
            /*prog.use();
            mat4 R = new mat4(1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
            cam.drawReflection(prog, R);
            prog.setUniform("mode", 0);
            glStencilFunc(GL_EQUAL, 3, ~0);
            glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
            player.draw(prog);
            Iterator<Enemy> eit = enemies.iterator();
            while(eit.hasNext())
            {
                eit.next().draw(prog);
            }
            glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
            glStencilFunc(GL_ALWAYS, 1, ~0);*/
            
            // DRAW WATER
            waterprog.use();
            cam.draw(waterprog);
            waterprog.setUniform("depthtexture", objDistBuffer.texture);
            waterprog.setUniform("reflectedtexture", planarRefBuffer.texture);
            waterprog.setUniform("skytexture", skybox.texture);
            waterprog.setUniform("eyepos", cam.eye);
            waterprog.setUniform("winsize", new vec2(1024, 1000));
            waterprog.setUniform("hitheryon", new vec2(cam.hither, cam.yon));
            water.draw(waterprog);
            waterprog.setUniform("depthtexture", dummytex);
            waterprog.setUniform("reflectedtexture", dummytex);
            
            // DRAW HUD STUFF (HEALTH/BOOSTBARS, ONSCREEN MESSAGES, ETC)
            prog.use();
            prog.setUniform("mode", 3);
            healthbar.draw(prog);
            // THIS SETS PROJ MATRIX TO IDENTITY DON"T PUT ANY 3D DRAWING CODE
            // AFTER THIS WITHOUT RESETTING IT
            boostbar.draw(prog);
            if(health <= 0)
            {
                prog.setUniform("worldMatrix", mat4.identity());
                gameover.draw(prog);
            }
            if(paused && health > 0)
            {
                prog.setUniform("worldMatrix", mat4.identity());
                pauseScreen.draw(prog);
            } 
            if(now < (wave1Timer + 3))
            {
                prog.setUniform("worldMatrix", mat4.identity());
                wave1.draw(prog);
            }
            if(now > wave2Timer && now < wave2Timer + 3)
            {
                prog.setUniform("worldMatrix", mat4.identity());
                wave2.draw(prog);
            }
            if(now > wave3Timer && now < wave3Timer + 3)
            {
                prog.setUniform("worldMatrix", mat4.identity());
                wave3.draw(prog);
            }
            if(now > wave4Timer && now < wave4Timer + 3)
            {
                prog.setUniform("worldMatrix", mat4.identity());
                wave4.draw(prog);
            }
            
            // DRAW BULLETS AND SHIELD TO FBO2
            fbo1.unbind();
            fbo2.bind();
            glClearColor(0, 0, 0, 1);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            cam.draw(prog);
            Iterator<Bullet> bit = bullets.iterator();
            while(bit.hasNext())
            {
                Bullet b = bit.next();
                prog.setUniform("mode", 2);
                b.draw(prog);
            }
            if(shielded)
            {
                prog.setUniform("mode", 9);
                prog.setUniform("worldMatrix", mul(scaling(new vec3(0.5, 0.5, 0.5)), translation(player.pos)));
                shield.draw(prog);
            }
            while(expit.hasNext())
            {
                if(expit.next().type == 1)
                {
                    ParticleSystem e = expit.next();
                    prog.setUniform("t", e.ptimer);
                    prog.setUniform("alpha", e.alpha);
                    e.draw(prog, elapsed);
                }
            }
            fbo2.unbind();
            // DRAW BULLETS TO FBO3 AND DO FIRST ROUND OF BLURRING 
            fbo3.bind();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            blurprog.use();
            blurprog.setUniform("diffuse_texture",fbo2.texture);
            blurprog.setUniform("blurring", 1);
            blurprog.setUniform("blurDelta", new vec2(1.0f, 0.0f));
            usq.draw(prog);
            blurprog.setUniform("diffuse_texture", dummytex);
            fbo3.unbind();
            // SECOND ROUND OF BLURRING
            fbo2.bind();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            blurprog.setUniform("diffuse_texture", fbo3.texture);
            blurprog.setUniform("blurDelta", new vec2(0.0f, 1.0f));
            usq.draw(prog);
            blurprog.setUniform("diffuse_texture", dummytex);
            fbo2.unbind();
            // THIRD ROUND OF BLURRING
            fbo3.bind();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            blurprog.use();
            blurprog.setUniform("diffuse_texture",fbo2.texture);
            blurprog.setUniform("blurring", 1);
            blurprog.setUniform("blurDelta", new vec2(1.0f, 0.0f));
            usq.draw(prog);
            blurprog.setUniform("diffuse_texture", dummytex);
            fbo3.unbind();
            // FOURTH ROUND OF BLURRING
            fbo2.bind();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            blurprog.setUniform("diffuse_texture", fbo3.texture);
            blurprog.setUniform("blurDelta", new vec2(0.0f, 1.0f));
            usq.draw(prog);
            blurprog.setUniform("diffuse_texture", dummytex);
            fbo2.unbind();
            // FIFTH ROUND OF BLURRING
            fbo3.bind();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            blurprog.use();
            blurprog.setUniform("diffuse_texture",fbo2.texture);
            blurprog.setUniform("blurring", 1);
            blurprog.setUniform("blurDelta", new vec2(1.0f, 0.0f));
            usq.draw(prog);
            blurprog.setUniform("diffuse_texture", dummytex);
            fbo3.unbind();
            // SIXTH ROUND OF BLURRING
            fbo2.bind();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            blurprog.setUniform("diffuse_texture", fbo3.texture);
            blurprog.setUniform("blurDelta", new vec2(0.0f, 1.0f));
            usq.draw(prog);
            blurprog.setUniform("diffuse_texture", dummytex);
            fbo2.unbind();
            // SEVENTH ROUND OF BLURRING
            fbo3.bind();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            blurprog.use();
            blurprog.setUniform("diffuse_texture",fbo2.texture);
            blurprog.setUniform("blurring", 1);
            blurprog.setUniform("blurDelta", new vec2(1.0f, 0.0f));
            usq.draw(prog);
            blurprog.setUniform("diffuse_texture", dummytex);
            fbo3.unbind();
            // EIGHTH ROUND OF BLURRING
            fbo2.bind();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            blurprog.setUniform("diffuse_texture", fbo3.texture);
            blurprog.setUniform("blurDelta", new vec2(0.0f, 1.0f));
            usq.draw(prog);
            fbo2.unbind();
            
            // DRAW EVERYTHING TO THE SCREEN -- NORMAL SCENE IN FBO1 PLUS THE BLURRED BULLETS IN FBO2 TO GET GLOWY BULLETS
            glClearColor(0.2f, 0.4f, 0.6f, 1.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
            blurprog.use();
            blurprog.setUniform("blurring", 0);
            blurprog.setUniform("adding", 1);
            blurprog.setUniform("diffuse_texture", fbo1.texture);
            blurprog.setUniform("glow_texture", fbo2.texture);
            usq.draw(blurprog);
            blurprog.setUniform("diffuse_texture",dummytex);
            blurprog.setUniform("glow_texture", dummytex);

            SDL_GL_SwapWindow(win);


        }//endwhile
    }//end main
}