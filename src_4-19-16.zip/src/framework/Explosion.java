package framework;

import framework.math3d.mat4;
import static framework.math3d.math3d.mul;
import static framework.math3d.math3d.scaling;
import static framework.math3d.math3d.translation;
import framework.math3d.vec2;
import framework.math3d.vec3;
import framework.math3d.vec4;

public class Explosion 
{
    vec4 pos;
    vec2 scale;
    Mesh mesh;
    int frame;
    
    public Explosion(vec4 p, Mesh m)
    {
        pos = p;
        scale = new vec2(1, 1);
        mesh = m;
        frame = 0;
    }
    
    public void draw(Program prog)
    {
        int col = frame % 5;
        int row = 3 - (frame / 5);
        mat4 textureMatrix = mul(scaling(new vec3(.2, .2, .2)), translation(col*.2f, row*.2f, 0));
        prog.setUniform("textureMatrix", textureMatrix);
        prog.setUniform("worldMatrix", translation(pos));
        prog.setUniform("bpScale", scale);
        prog.setUniform("mode", 8);
        mesh.draw(prog);
    }
}
