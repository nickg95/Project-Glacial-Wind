package framework;

import java.util.ArrayList;
import java.util.TreeMap;

public class Grid<E> 
{
    float xmin, xmax, zmin, zmax, size;
    TreeMap<Integer, TreeMap<Integer, ArrayList<E>>> G;
    
    public Grid(float xmin, float xmax, float zmin, float zmax, float s)
    {
        this.xmin = xmin;
        this.xmax = xmax;
        this.zmin = zmin;
        this.zmax = zmax;
        this.size = s;
        this.G = new TreeMap<>();
    }
    
    public int[] put(float objx, float objz, E obj, int[] oldcell)
    {
        int newcellx = (int) ((objx - xmin) / size);
        int newcellz = (int) ((objz - zmin) / size);
        
        if(oldcell != null && newcellx == oldcell[0] && newcellz == oldcell[1])
        {
            return new int[]{newcellx, newcellz};
        }
        if(oldcell != null)
        {
            G.get(oldcell[0]).get(oldcell[1]).remove(obj);
        }
        
        if(!G.containsKey(newcellx))
        {
            G.put(newcellx, new TreeMap<>());
        }
        if(!G.get(newcellx).containsKey(newcellz))
        {
            G.get(newcellx).put(newcellz, new ArrayList<>());
        }
        
        G.get(newcellx).get(newcellz).add(obj);
        return new int[]{newcellx, newcellz};
    }
    
    public ArrayList getNeighbors(int[] cell)
    {
        ArrayList N = new ArrayList();
        for(int i = cell[0] - 1; i <= cell[0] + 1; i++)
        {
            for(int j = cell[1] - 1; j <= cell[1] + 1; j++)
            {
                if(G.containsKey(i) && G.get(i).containsKey(j))
                {
                    N.add(new int[]{i, j});
                }
            }
        }
        
        return N;
    }
}
