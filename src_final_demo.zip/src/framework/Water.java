package framework;

import framework.math3d.mat4;
import framework.math3d.vec4;
import static framework.math3d.math3d.*;
import framework.math3d.vec3;

public class Water 
{
    Mesh mesh;
    mat4 scale;
    mat4 rotate;
    mat4 translate;
    vec4 pos;
    int vao;
    int ibuff;
    float rotation;
    
    public Water(vec4 p, float r, Mesh m)
    {
        mesh = m;
        pos = p;
        rotation = r;
        rotate = axisRotation(new vec3(0, 1, 0), rotation);
        translate = translation(pos);
        scale = scaling(0.5f, 1, 0.5f);
    }
    
    public void draw (Program prog)
    {
        prog.setUniform("worldMatrix", mul(rotate, scale, translate));
        mesh.draw(prog);
        System.out.println(Math.sqrt(mesh.numvertices));
    }
}
