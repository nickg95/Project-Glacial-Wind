package framework;

import framework.math3d.vec4;
import java.util.ArrayList;
import java.util.Random;


public class Wave 
{
    public int waveNum;
    private Random rand;
    
    public Wave(int num)
    {
        waveNum = num;
        rand = new Random();
    }
    
    public void spawnEnemies(ArrayList enemies, Mesh car, Mesh wheel, Mesh tank)
    {
        if(waveNum == 1)
        {
            for(int n = 0; n <= 10; n++)
            {
                int x = rand.nextInt(50) - 25;
                int z = rand.nextInt(50);
                Enemy e = new Enemy(new vec4(x, 0, z, 1), car, wheel, 0);
                enemies.add(e);
            }
            int x = rand.nextInt(50) - 25;
            int z = rand.nextInt(50);
            Enemy e = new Enemy(new vec4(x, 0, z, 1), tank, 1);
            enemies.add(e);
        }
        else if(waveNum == 2)
        {
            for(int n = 0; n <= 15; n++)
            {
                int x = rand.nextInt(50) - 25;
                int z = rand.nextInt(50);
                Enemy e = new Enemy(new vec4(x, 0, z, 1), car, wheel, 0);
                enemies.add(e);
            }
            for(int t = 0; t <= 3; t++)
            {
                int x = rand.nextInt(50) - 25;
                int z = rand.nextInt(50);
                Enemy e = new Enemy(new vec4(x, 0, z, 1), tank, 1);
                enemies.add(e);
            }
        }
        else if(waveNum == 3)
        {
            for(int n = 0; n <= 20; n++)
            {
                int x = rand.nextInt(50) - 25;
                int z = rand.nextInt(50);
                Enemy e = new Enemy(new vec4(x, 0, z, 1), car, wheel, 0);
                enemies.add(e);
            }
            for(int t = 0; t <= 4; t++)
            {
                int x = rand.nextInt(50) - 25;
                int z = rand.nextInt(50);
                Enemy e = new Enemy(new vec4(x, 0, z, 1), tank, 1);
                enemies.add(e);
            }
        }
        else if(waveNum == 4)
        {
            for(int n = 0; n <= 25; n++)
            {
                int x = rand.nextInt(50) - 25;
                int z = rand.nextInt(50);
                Enemy e = new Enemy(new vec4(x, 0, z, 1), car, wheel, 0);
                enemies.add(e);
            }
            for(int t = 0; t <= 6; t++)
            {
                int x = rand.nextInt(50) - 25;
                int z = rand.nextInt(50);
                Enemy e = new Enemy(new vec4(x, 0, z, 1), tank, 1);
                enemies.add(e);
            }
        }
        else if(waveNum == 5)
        {
            for(int n = 0; n <= 30; n++)
            {
                int x = rand.nextInt(50) - 25;
                int z = rand.nextInt(50);
                Enemy e = new Enemy(new vec4(x, 0, z, 1), car, wheel, 0);
                enemies.add(e);
            }
            for(int t = 0; t <= 8; t++)
            {
                int x = rand.nextInt(50) - 25;
                int z = rand.nextInt(50);
                Enemy e = new Enemy(new vec4(x, 0, z, 1), tank, 1);
                enemies.add(e);
            }
        }
    }
}
