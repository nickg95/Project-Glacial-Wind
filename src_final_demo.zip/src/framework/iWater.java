package framework;

import framework.math3d.mat4;
import static JGL.JGL.*;
import static framework.math3d.math3d.mul;
import static framework.math3d.math3d.scaling;
import static framework.math3d.math3d.translation;
import framework.math3d.vec2;
import framework.math3d.vec3;
import framework.math3d.vec4;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

class iWater
{
    SolidTexture dummytex;
    mat4 worldMatrix;
    int F;
    int D;
    int q;
    float t;
    float d;
    float n;
    int sz;
    int pidx;
    float total_elapsed;
    int num_triangles;
    int vao;
    GPUBuffer[] buffers;
    
    public iWater(float num, int size)
    {
        dummytex = new SolidTexture(GL_UNSIGNED_BYTE, 0, 0, 0, 0);
        worldMatrix = mat4.identity();
        F = 1;
        D = 1;
        q = 1;
        t = 0.01f;
        d = 0.01f;
        n = num;
        sz = size;
        pidx = 0;
        total_elapsed = 0.0f;
        
        float minx = -sz / 2;
        float maxx = sz / 2;
        float minz = -sz / 2;
        float maxz = sz / 2;
        
        num_triangles = (int) ((n-1) * (n-1) * 2);
        ByteBuffer bb = ByteBuffer.allocate(num_triangles*3*4*4);
        bb.order(ByteOrder.nativeOrder());
        float[] data = new float[num_triangles*3*4];
        int idx = 0;
        for(int itmp = 0; itmp < n-1; itmp++)
        {
            for(int jtmp = 0; jtmp < n-1; jtmp++)
            {
                float i = itmp / n; //percent across horizontally
                float j = jtmp / n; //percent across vertically
                float inext = ((itmp+1) / n);
                float jnext = (jtmp+1) / n;
                float ax = minx + (i * sz);
                float az = minz + (j * sz);
                float bx = minx + (inext * sz);
                float cz = minz + (jnext * sz);
                //pack the row/col into z/w to use as input in vertex shader
                //first triangle of quad
                data[idx++] = ax; data[idx++] = az; data[idx++] = i; data[idx++] = j;
                data[idx++] = ax; data[idx++] = cz; data[idx++] = i; data[idx++] = jnext;
                data[idx++] = bx; data[idx++] = az; data[idx++] = inext; data[idx++] = j;
                //second triangle of quad
                data[idx++] = ax; data[idx++] = cz; data[idx++] = i; data[idx++] = jnext;
                data[idx++] = bx; data[idx++] = cz; data[idx++] = inext; data[idx++] = jnext;
                data[idx++] = bx; data[idx++] = az; data[idx++] = inext; data[idx++] = j;
            }
        }
        bb.asFloatBuffer().put(data);
        byte[] bdata = bb.array();
        int[] temp = new int[1];
        glGenVertexArrays(1, temp);
        vao = temp[0];
        glBindVertexArray(vao);
        glGenBuffers(1, temp);
        int vbuff = temp[0];
        glBindBuffer(GL_ARRAY_BUFFER, vbuff);
        glBufferData(GL_ARRAY_BUFFER, bdata.length, bdata, GL_STATIC_DRAW);
        glEnableVertexAttribArray(Program.POSITION_INDEX);
        glVertexAttribPointer(Program.POSITION_INDEX, 4, GL_FLOAT, false, 4*4, 0);
        glBindVertexArray(0);
        
        buffers = new GPUBuffer[3];
        int buffersize = (int) (n*n*4);
        float[] bufferdata = new float[buffersize];
        buffers[0] = new GPUBuffer(bufferdata);
        buffers[1] = new GPUBuffer(bufferdata);
        buffers[2] = new GPUBuffer(bufferdata);
    }
    
    public void update(float elapsed, ArrayList<float[]> pending_ripples, Program prog)
    {
        total_elapsed += elapsed;
        float scaledtime = t*4;
        while(total_elapsed >= scaledtime)
        {
            GPUBuffer prev = buffers[pidx];
            GPUBuffer curr = buffers[(pidx + 1) % 3];
            GPUBuffer next = buffers[(pidx + 2) % 3];
            
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 0, prev.buffer);
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 1, curr.buffer);
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 2, next.buffer);
            
            prog.setUniform("worldMatrix", worldMatrix);
            prog.setUniform("size", new vec2(sz, sz));
            prog.setUniform("halfsize", new vec2(sz * 0.5, sz * 0.5));
            prog.setUniform("d", d);
            prog.setUniform("T1", (2*F*t*t/(D*d)));
            prog.setUniform("T2", q*d-2);
            prog.setUniform("T3", 4-(8*F*t*t/(D*d)));
            prog.setUniform("T4", q*t+2);
            if(!pending_ripples.isEmpty())
            {
                float[] ripple = pending_ripples.get(0);
                prog.setUniform("rippleposx", ripple[0]);
                prog.setUniform("rippleposy", ripple[1]);
                prog.setUniform("rippleposz", ripple[2]);
                prog.setUniform("ripplepower", ripple[3]);
                prog.setUniform("rippledist", ripple[4]);
                pending_ripples.remove(ripple);
            }
            else
            {
                prog.setUniform("rippleposx", 0);
                prog.setUniform("rippleposy", 0);
                prog.setUniform("rippleposz", 0);
                prog.setUniform("ripplepower", 1.0);
                prog.setUniform("rippledist", 0.0);
            }
            prog.dispatch((int) n, 1, (int) n);
            
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 0, 0);
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 1, 0);
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 2, 0);
            
            pidx = (pidx + 1) % 3;
            total_elapsed -= scaledtime;
        }
    }
    
    public void draw(Camera cam, vec4 lightpos, Program prog)
    {
        cam.draw(prog);
        prog.setUniform("lightPos", new vec4(lightpos));
        prog.setUniform("eyepos", new vec4(cam.eye));
        prog.setUniform("worldMatrix", worldMatrix);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 0, buffers[(pidx+1)%3].buffer);
        glBindVertexArray(vao);
        glDrawArrays(GL_TRIANGLES, 0, num_triangles*3);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 0, 0);
    }
}